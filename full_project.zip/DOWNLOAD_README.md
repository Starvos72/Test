# Potato Optimizer AI - Multi-Version Release

## 📦 Files Available for Download

### 1. **PotatoOptimizerAI-v1.0.0-Source.zip** (13KB)
   - Complete source code in ZIP format
   - Includes all configuration files for multi-version support
   - **Best for**: Windows users, easy extraction

### 2. **PotatoOptimizerAI-v1.0.0-Source.tar.gz** (3.4KB)
   - Complete source code in TAR.GZ format
   - Compressed source files
   - **Best for**: Linux/Mac users

### 3. **PotatoOptimizerAI-1.0.0.jar** (8.2KB)
   - Pre-built JAR file (original)
   - **Note**: Test with your target versions first

---

## ✅ Multi-Version Support Configuration

Your mod is now configured to support **Minecraft 1.20 through 1.21.11**:

### Build Configuration (`build.gradle`)
```gradle
minecraft "com.mojang:minecraft:1.20.4"
mappings "net.fabricmc:yarn:1.20.4+build.3:v2"
modImplementation "net.fabricmc:fabric-loader:0.15.11"
modImplementation "net.fabricmc.fabric-api:fabric-api:0.97.2+1.20.4"
```

### Mod Metadata (`fabric.mod.json`)
```json
"depends": {
  "minecraft": ">=1.20 <1.22",
  "fabricloader": "*",
  "fabric-api": "*"
}
```

---

## 🚀 How to Build

### Prerequisites
- Java 17 or higher
- Gradle (included via wrapper)

### Build Steps
```bash
# Extract the archive
unzip PotatoOptimizerAI-v1.0.0-Source.zip
cd extracted_zip

# Build the mod
./gradlew clean build

# Output JAR will be in build/libs/
```

### Supported Versions
- ✅ Minecraft 1.20.x (1.20.0, 1.20.1, 1.20.2, 1.20.4, etc.)
- ✅ Minecraft 1.21.0
- ✅ Minecraft 1.21.1
- ✅ Minecraft 1.21.2+

---

## 📝 Key Changes Made

1. **Updated Minecraft Target**: 1.20.4 (stable build base)
2. **Version Range**: `>=1.20 <1.22` (covers all 1.20.x and 1.21.x versions)
3. **Fabric API**: Updated to 0.97.2+1.20.4 (multi-version compatible)
4. **Gradle Wrapper**: Pre-configured for reliable builds

---

## 📖 Installation

1. Download the JAR file from `build/libs/` after building
2. Place in your Minecraft mods folder: `.minecraft/mods/`
3. Launch Minecraft with Fabric Loader
4. The mod will automatically work on any supported version

---

## ❓ Troubleshooting

**"Build failed" error?**
- Ensure you have Java 17+ installed: `java -version`
- Try: `./gradlew clean build --refresh-dependencies`
- Check your internet connection (dependencies are downloaded)

**"Unsupported Minecraft version" error?**
- The mod supports 1.20.0 through 1.21.11
- Verify your Minecraft version matches this range

---

## 📧 Support

Created by: Starvos, Insaan
License: MIT

**Version**: 1.0.0
**Release Date**: 2026-01-31
