package com.potatooptimizerai.screen;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import com.potatooptimizerai.config.ModConfig;
import com.potatooptimizerai.performance.PerformanceHandler;
import com.potatooptimizerai.performance.PerformanceMode;

/**
 * Configuration GUI Screen
 */
public class ConfigScreen extends Screen {
    private final Screen parent;
    private int selectedTabIndex = 0;
    
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 25;
    
    public ConfigScreen(Screen parent) {
        super(Text.literal("Potato Optimizer AI v1.2.2 - Config"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
        
        int startX = this.width / 2 - BUTTON_WIDTH / 2;
        int startY = 50;
        int buttonIndex = 0;

        // Title
        // this.textRenderer.draw(matrixStack, "Potato Optimizer AI - Configuration", startX - 50, 30, 0xFFFFFF);

        // Mode Selection Buttons
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Mode: " + PerformanceHandler.getCurrentMode().name),
            button -> cycleMode()
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // AI Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableAIOptimization ? "✓ AI Optimization" : "✗ AI Optimization"),
            button -> ModConfig.enableAIOptimization = !ModConfig.enableAIOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Entity Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableEntityOptimization ? "✓ Entity Optimization" : "✗ Entity Optimization"),
            button -> ModConfig.enableEntityOptimization = !ModConfig.enableEntityOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Block Entity Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableBlockEntityOptimization ? "✓ Block Entity Opt" : "✗ Block Entity Opt"),
            button -> ModConfig.enableBlockEntityOptimization = !ModConfig.enableBlockEntityOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Particle Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableParticleOptimization ? "✓ Particle Optimization" : "✗ Particle Optimization"),
            button -> ModConfig.enableParticleOptimization = !ModConfig.enableParticleOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // GPU Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableGPUOptimization ? "✓ GPU Optimization" : "✗ GPU Optimization"),
            button -> ModConfig.enableGPUOptimization = !ModConfig.enableGPUOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Memory Optimization Toggle
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.enableMemoryOptimization ? "✓ Memory Optimization" : "✗ Memory Optimization"),
            button -> ModConfig.enableMemoryOptimization = !ModConfig.enableMemoryOptimization
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Gameplay Mode Buttons
        buttonIndex++; // Extra spacing

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.streamingMode ? "✓ Streaming Mode" : "○ Streaming Mode"),
            button -> ModConfig.streamingMode = !ModConfig.streamingMode
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.peaceMode ? "✓ Peace Mode" : "○ Peace Mode"),
            button -> ModConfig.peaceMode = !ModConfig.peaceMode
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.pvpMode ? "✓ PvP Mode" : "○ PvP Mode"),
            button -> ModConfig.pvpMode = !ModConfig.pvpMode
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.buildingMode ? "✓ Building Mode" : "○ Building Mode"),
            button -> ModConfig.buildingMode = !ModConfig.buildingMode
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        this.addDrawableChild(ButtonWidget.builder(
            Text.literal(ModConfig.shaderMode ? "✓ Shader Mode" : "○ Shader Mode"),
            button -> ModConfig.shaderMode = !ModConfig.shaderMode
        ).dimensions(startX, startY + (buttonIndex++ * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // Save and Close
        buttonIndex++; // Extra spacing
        
        this.addDrawableChild(ButtonWidget.builder(
            Text.literal("Save & Close"),
            button -> {
                ModConfig.save();
                this.close();
            }
        ).dimensions(startX, startY + (buttonIndex * BUTTON_SPACING), BUTTON_WIDTH, BUTTON_HEIGHT).build());
    }

    private void cycleMode() {
        PerformanceMode current = PerformanceHandler.getCurrentMode();
        PerformanceMode next = current == PerformanceMode.NORMAL ? PerformanceMode.BALANCED :
                               current == PerformanceMode.BALANCED ? PerformanceMode.AGGRESSIVE :
                               PerformanceMode.NORMAL;
        PerformanceHandler.setCurrentMode(next);
        this.clearAndInit();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
        
        // Display current FPS
        String fpsText = String.format("FPS: %.1f", PerformanceHandler.getCurrentFps());
        context.drawTextWithShadow(this.textRenderer, Text.literal(fpsText), 10, 10, 0x00FF00);
        
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
