package com.potatooptimizerai.mixins;

import com.potatooptimizerai.config.ModConfig;
import com.potatooptimizerai.performance.ParticleOptimizer;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    
    @Inject(method = "render", at = @At("HEAD"))
    private void optimizeRendering(CallbackInfo ci) {
        if (!ModConfig.enableParticleOptimization) return;
        
        // Disable fog if configured
        if (ParticleOptimizer.shouldDisableFog()) {
            // Fog disabling would be handled through mixin on fog rendering
        }
        
        // Disable vignette if configured
        if (ParticleOptimizer.shouldDisableVignette()) {
            // Vignette disabling would be handled through render target
        }
    }
}
