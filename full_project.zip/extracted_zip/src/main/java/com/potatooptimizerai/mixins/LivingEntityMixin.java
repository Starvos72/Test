package com.potatooptimizerai.mixins;

import com.potatooptimizerai.config.ModConfig;
import com.potatooptimizerai.performance.PerformanceHandler;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    
    @Inject(method = "getMaxHealth", at = @At("RETURN"), cancellable = true)
    private void optimizeHealthRendering(CallbackInfoReturnable<Float> cir) {
        if (!ModConfig.enableParticleOptimization) return;
        
        // This can be used for other optimizations
    }
}
