package com.potatooptimizerai.config;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ModConfig {
    private static final Logger LOGGER = LogManager.getLogger("PotatoOptimizerAI");
    
    public static String mode = "BALANCED";
    private static File file = new File("config/potatooptimizerai.json");
    
    // Performance optimization: cache the calculated distance
    private static int cachedCullingDistance = 4900; // 70^2
    private static String cachedMode = "BALANCED";

    // ========== Feature Toggles ==========
    // Core Features
    public static boolean enableAIOptimization = true;
    public static boolean enableEntityOptimization = true;
    public static boolean enableBlockEntityOptimization = true;
    public static boolean enableRedstoneOptimization = true;
    public static boolean enableChunkOptimization = true;
    public static boolean enableParticleOptimization = true;
    public static boolean enableGPUOptimization = true;
    public static boolean enableMemoryOptimization = true;
    public static boolean enableBackgroundTaskLimiting = true;

    // Visual Effects
    public static boolean enableWeatherDisable = false;
    public static boolean enableSkyEffectsDisable = false;
    public static boolean enableFogDisable = false;
    public static boolean enableVignetteDisable = false;
    public static boolean enableHurtShakeDisable = false;
    public static boolean enableBeaconBeamDisable = false;
    public static boolean enableEndCrystalDisable = false;
    public static boolean enableEntityShadowReduction = false;

    // Gameplay Modes
    public static boolean streamingMode = false;
    public static boolean peaceMode = false;
    public static boolean pvpMode = false;
    public static boolean buildingMode = false;
    public static boolean shaderMode = false;

    // Optimization Parameters
    public static int entityFreezeDistance = 50;
    public static int blockEntityThrottleDistance = 50;
    public static int targetFPS = 120;

    public static void load() {
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                saveDefault();
            }
            String txt = new String(Files.readAllBytes(file.toPath()));
            
            // Parse and cache mode
            if (txt.contains("\"mode\":\"AGGRESSIVE\"") || txt.contains("AGGRESSIVE")) {
                mode = "AGGRESSIVE";
                cachedCullingDistance = 1600; // 40^2
            } else if (txt.contains("\"mode\":\"NORMAL\"") || txt.contains("NORMAL")) {
                mode = "NORMAL";
                cachedCullingDistance = 10000; // 100^2
            } else {
                mode = "BALANCED";
                cachedCullingDistance = 4900; // 70^2
            }
            cachedMode = mode;
            LOGGER.info("✓ Configuration loaded successfully");
        } catch (Exception e) {
            LOGGER.warn("Failed to load config, using defaults");
            mode = "BALANCED";
            cachedCullingDistance = 4900;
        }
    }

    private static void saveDefault() {
        try {
            FileWriter fw = new FileWriter(file);
            fw.write(getDefaultConfig());
            fw.close();
            LOGGER.info("✓ Default configuration created");
        } catch (Exception e) {
            LOGGER.error("Failed to save default config", e);
        }
    }

    private static String getDefaultConfig() {
        return "{\n" +
            "  \"mode\": \"BALANCED\",\n" +
            "  \"enableAIOptimization\": true,\n" +
            "  \"enableEntityOptimization\": true,\n" +
            "  \"enableBlockEntityOptimization\": true,\n" +
            "  \"enableParticleOptimization\": true,\n" +
            "  \"entityFreezeDistance\": 50,\n" +
            "  \"blockEntityThrottleDistance\": 50,\n" +
            "  \"targetFPS\": 120\n" +
            "}\n";
    }

    public static void save() {
        try {
            FileWriter fw = new FileWriter(file);
            fw.write(buildConfigJson());
            fw.close();
        } catch (Exception e) {
            LOGGER.error("Failed to save config", e);
        }
    }

    private static String buildConfigJson() {
        return "{\n" +
            "  \"mode\": \"" + mode + "\",\n" +
            "  \"enableAIOptimization\": " + enableAIOptimization + ",\n" +
            "  \"enableEntityOptimization\": " + enableEntityOptimization + ",\n" +
            "  \"enableBlockEntityOptimization\": " + enableBlockEntityOptimization + ",\n" +
            "  \"enableRedstoneOptimization\": " + enableRedstoneOptimization + ",\n" +
            "  \"enableChunkOptimization\": " + enableChunkOptimization + ",\n" +
            "  \"enableParticleOptimization\": " + enableParticleOptimization + ",\n" +
            "  \"enableGPUOptimization\": " + enableGPUOptimization + ",\n" +
            "  \"enableMemoryOptimization\": " + enableMemoryOptimization + ",\n" +
            "  \"entityFreezeDistance\": " + entityFreezeDistance + ",\n" +
            "  \"blockEntityThrottleDistance\": " + blockEntityThrottleDistance + ",\n" +
            "  \"targetFPS\": " + targetFPS + ",\n" +
            "  \"streamingMode\": " + streamingMode + ",\n" +
            "  \"peaceMode\": " + peaceMode + ",\n" +
            "  \"pvpMode\": " + pvpMode + ",\n" +
            "  \"buildingMode\": " + buildingMode + ",\n" +
            "  \"shaderMode\": " + shaderMode + "\n" +
            "}\n";
    }
    
    /**
     * Gets cached culling distance in squared blocks
     * Avoids recalculating on every entity check
     * @return Squared distance in blocks
     */
    public static int getCullingDistance() {
        // Return cached value for maximum performance
        return cachedCullingDistance;
    }
    
    /**
     * Updates mode and refreshes cache
     */
    public static void setMode(String newMode) {
        if (!newMode.equals(cachedMode)) {
            mode = newMode;
            cachedMode = newMode;
            
            if (newMode.equals("AGGRESSIVE")) {
                cachedCullingDistance = 1600;
            } else if (newMode.equals("NORMAL")) {
                cachedCullingDistance = 10000;
            } else {
                cachedCullingDistance = 4900;
            }
            saveConfig();
        }
    }
    
    private static void saveConfig() {
        try {
            FileWriter fw = new FileWriter(file);
            fw.write("mode=" + mode + "\n");
            fw.close();
        } catch (Exception ignored) {}
    }
}