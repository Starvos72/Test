package com.potatooptimizerai.util;

import net.minecraft.client.MinecraftClient;

/**
 * Performance metrics tracker for debugging and optimization
 */
public class PerformanceMetrics {
    
    private static long frameStartTime = 0;
    private static long lastFrameTime = 0;
    private static double averageFps = 60.0;
    
    private static int totalEntities = 0;
    private static int culledEntities = 0;
    private static int activeBlockEntities = 0;
    
    /**
     * Starts frame timing
     */
    public static void startFrame() {
        frameStartTime = System.nanoTime();
    }
    
    /**
     * Ends frame timing
     */
    public static void endFrame() {
        long frameTime = System.nanoTime() - frameStartTime;
        lastFrameTime = frameTime;
    }
    
    /**
     * Gets last frame time in milliseconds
     */
    public static double getLastFrameTimeMs() {
        return lastFrameTime / 1_000_000.0;
    }
    
    /**
     * Records entity statistics
     */
    public static void recordEntityStats(int total, int culled, int blockEntities) {
        totalEntities = total;
        culledEntities = culled;
        activeBlockEntities = blockEntities;
    }
    
    /**
     * Gets total entity count
     */
    public static int getTotalEntities() {
        return totalEntities;
    }
    
    /**
     * Gets culled entity count
     */
    public static int getCulledEntities() {
        return culledEntities;
    }
    
    /**
     * Gets active block entity count
     */
    public static int getActiveBlockEntities() {
        return activeBlockEntities;
    }
    
    /**
     * Gets optimization efficiency (0-100%)
     */
    public static float getOptimizationEfficiency() {
        if (totalEntities == 0) return 0;
        return (culledEntities * 100.0f) / totalEntities;
    }
    
    /**
     * Gets memory usage percentage
     */
    public static float getMemoryUsagePercent() {
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        return (usedMemory * 100.0f) / maxMemory;
    }
}
