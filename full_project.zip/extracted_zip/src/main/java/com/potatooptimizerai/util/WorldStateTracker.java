package com.potatooptimizerai.util;

import net.minecraft.client.MinecraftClient;

/**
 * World state tracker for detecting player activity and visibility
 */
public class WorldStateTracker {
    
    private static long lastPlayerMovement = 0;
    private static long lastPlayerInteraction = 0;
    private static final long IDLE_THRESHOLD = 30_000; // 30 seconds
    
    /**
     * Updates last player movement time
     */
    public static void onPlayerMove() {
        lastPlayerMovement = System.currentTimeMillis();
    }
    
    /**
     * Updates last player interaction time
     */
    public static void onPlayerInteract() {
        lastPlayerInteraction = System.currentTimeMillis();
    }
    
    /**
     * Checks if player is currently idle
     */
    public static boolean isPlayerIdle() {
        long now = System.currentTimeMillis();
        return (now - Math.max(lastPlayerMovement, lastPlayerInteraction)) > IDLE_THRESHOLD;
    }
    
    /**
     * Gets chunks around player
     */
    public static int getPlayerChunkX(MinecraftClient mc) {
        if (mc.player == null) return 0;
        return (int) (mc.player.getX() / 16);
    }
    
    /**
     * Gets chunks around player (Z axis)
     */
    public static int getPlayerChunkZ(MinecraftClient mc) {
        if (mc.player == null) return 0;
        return (int) (mc.player.getZ() / 16);
    }
    
    /**
     * Checks if specific chunk is loaded
     */
    public static boolean isChunkLoaded(MinecraftClient mc, int chunkX, int chunkZ) {
        if (mc.world == null) return false;
        return mc.world.getChunkManager().isChunkLoaded(chunkX, chunkZ);
    }
}
