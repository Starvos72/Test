package com.potatooptimizerai.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Debug utilities for monitoring optimization status
 */
public class DebugUtils {
    private static final Logger LOGGER = LogManager.getLogger("PotatoOptimizerAI");
    
    private static boolean debugModeEnabled = false;
    
    /**
     * Enables debug logging
     */
    public static void enableDebugMode() {
        debugModeEnabled = true;
        LOGGER.info("✓ Debug Mode ENABLED");
    }
    
    /**
     * Disables debug logging
     */
    public static void disableDebugMode() {
        debugModeEnabled = false;
        LOGGER.info("✓ Debug Mode DISABLED");
    }
    
    /**
     * Logs debug message if debug mode is enabled
     */
    public static void debug(String message, Object... args) {
        if (debugModeEnabled) {
            LOGGER.info("[DEBUG] " + message, args);
        }
    }
    
    /**
     * Logs optimization status
     */
    public static void logOptimizationStatus(
        String mode, double fps, int culledEntities, 
        float memoryUsage, int activeChunks) {
        
        if (debugModeEnabled) {
            LOGGER.info("=== Optimization Status ===");
            LOGGER.info("Mode: {} | FPS: {:.1f} | Memory: {:.1f}%",
                mode, fps, memoryUsage);
            LOGGER.info("Culled Entities: {} | Active Chunks: {}",
                culledEntities, activeChunks);
        }
    }
    
    /**
     * Checks if debug mode is enabled
     */
    public static boolean isDebugMode() {
        return debugModeEnabled;
    }
}
