package com.potatooptimizerai.input;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import com.potatooptimizerai.screen.ConfigScreen;
import net.minecraft.client.MinecraftClient;

/**
 * Handles keybindings for the mod
 */
public class KeybindingHandler {
    
    private static KeyBinding configScreenKeybind;
    
    public static void register() {
        // Register Shift + Right Click for config screen
        // Note: This is handled in mixin for better compatibility
    }
    
    /**
     * Opens config screen when triggered
     */
    public static void openConfigScreen() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.setScreen(new ConfigScreen(null));
        }
    }
    
    /**
     * Handles right-click input for config menu
     */
    public static boolean handleRightClick(boolean shiftPressed) {
        if (shiftPressed) {
            openConfigScreen();
            return true;
        }
        return false;
    }
}
