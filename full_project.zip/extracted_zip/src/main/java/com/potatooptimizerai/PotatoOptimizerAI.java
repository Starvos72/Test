package com.potatooptimizerai;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.potatooptimizerai.config.ModConfig;
import com.potatooptimizerai.performance.PerformanceHandler;
import com.potatooptimizerai.performance.MemoryOptimizer;
import com.potatooptimizerai.input.KeybindingHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PotatoOptimizerAI implements ClientModInitializer {
    
    private static final Logger LOGGER = LogManager.getLogger("PotatoOptimizerAI");
    public static final String MOD_VERSION = "1.2.3";
    
    @Override
    public void onInitializeClient() {
        // Load configuration with error handling
        try {
            ModConfig.load();
            LOGGER.info("✓ Potato Optimizer AI v{} initialized", MOD_VERSION);
            LOGGER.info("✓ Optimization Mode: {}", ModConfig.mode);
            LOGGER.info("✓ FPS Optimization: ENABLED");
            
            // Register tick events for performance monitoring
            ClientTickEvents.END_CLIENT_TICK.register(client -> {
                PerformanceHandler.tick();
                MemoryOptimizer.tick();
            });
            
            // Register keybinding handler
            KeybindingHandler.register();
            
        } catch (Exception e) {
            LOGGER.error("Failed to initialize Potato Optimizer AI", e);
        }
    }
}