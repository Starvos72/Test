package com.potatooptimizerai.performance;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Memory & Garbage Management - Prevents stuttering from GC pauses
 */
public class MemoryOptimizer {
    private static final Logger LOGGER = LogManager.getLogger("PotatoOptimizerAI");
    
    public static boolean enableMemoryOptimization = true;
    public static boolean preventAggressiveGC = true;
    
    private static long lastMemoryClean = 0;
    private static final long MEMORY_CHECK_INTERVAL = 10_000; // 10 seconds

    /**
     * Performs safe memory cleanup without freezing the game
     */
    public static void tick() {
        if (!enableMemoryOptimization) return;

        long now = System.currentTimeMillis();
        if (now - lastMemoryClean < MEMORY_CHECK_INTERVAL) {
            return;
        }

        lastMemoryClean = now;
        
        // Gentle memory suggestion (not forcing GC immediately)
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        double memoryUsagePercent = (usedMemory * 100.0) / maxMemory;

        // Only suggest GC if memory usage is very high
        if (memoryUsagePercent > 85) {
            LOGGER.debug("Memory usage high: {:.1f}%. Suggesting garbage collection.", memoryUsagePercent);
            // Note: We don't call System.gc() directly as it can cause stutters
            // Instead, we log and rely on Java's adaptive GC
        }
    }

    /**
     * Gets current memory usage percentage
     */
    public static float getMemoryUsagePercent() {
        Runtime runtime = Runtime.getRuntime();
        long maxMemory = runtime.maxMemory();
        long usedMemory = runtime.totalMemory() - runtime.freeMemory();
        return (usedMemory * 100.0f) / maxMemory;
    }

    /**
     * Clears unused caches safely (called periodically)
     */
    public static void clearCaches() {
        if (!enableMemoryOptimization) return;
        
        // This would be used in conjunction with modding framework
        // to clear caches that don't affect gameplay
    }
}
