package com.potatooptimizerai.performance;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.client.MinecraftClient;

/**
 * Entity Optimization Handler - Controls entity ticking and AI updates
 */
public class EntityOptimizer {
    
    // Configuration
    public static int entityFreezeDistance = 50; // blocks
    public static int maxActiveEntities = 256;
    public static boolean enableEntityFreeze = true;
    public static boolean reduceAIUpdates = true;
    public static boolean pauseOffscreenEntities = true;

    /**
     * Determines if an entity should be frozen (tick skipped)
     */
    public static boolean shouldFreezeEntity(Entity entity, MinecraftClient mc) {
        if (!enableEntityFreeze || mc.player == null) return false;
        if (entity.isPlayer() || entity == mc.player) return false;

        // Check distance
        double distSq = entity.squaredDistanceTo(mc.player);
        int freezeDistSq = entityFreezeDistance * entityFreezeDistance;
        
        if (distSq > freezeDistSq) {
            return true;
        }

        // Check if offscreen
        if (pauseOffscreenEntities && isEntityOffscreen(entity, mc)) {
            return true;
        }

        return false;
    }

    /**
     * Determines if entity should have reduced AI updates
     */
    public static boolean shouldReduceAIUpdates(Entity entity, MinecraftClient mc) {
        if (!reduceAIUpdates || !(entity instanceof MobEntity)) return false;

        double distSq = entity.squaredDistanceTo(mc.player);
        
        // Reduce AI updates for entities beyond 40 blocks
        return distSq > 1600;
    }

    /**
     * Checks if entity is visible on screen
     */
    public static boolean isEntityOffscreen(Entity entity, MinecraftClient mc) {
        if (mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) {
            return false;
        }
        
        // Simple frustum check using squared distance
        // In production, would use actual frustum culling
        double distSq = entity.squaredDistanceTo(mc.gameRenderer.getCamera().getPos());
        return distSq > 10000; // Beyond ~100 blocks
    }

    /**
     * Reduces pathfinding and navigation updates for mobs
     */
    public static float getAIUpdateMultiplier(Entity entity) {
        if (!(entity instanceof MobEntity mob)) return 1.0f;

        double dist = Math.sqrt(MinecraftClient.getInstance().player.squaredDistanceTo(entity));
        
        if (dist > 100) return 0.1f;  // 10% updates
        if (dist > 60) return 0.25f;  // 25% updates
        if (dist > 40) return 0.5f;   // 50% updates
        return 1.0f;
    }

    /**
     * Reduces villager and animal updates
     */
    public static boolean shouldReduceAnimalUpdates(Entity entity) {
        if (!(entity instanceof AnimalEntity) && !(entity instanceof VillagerEntity)) {
            return false;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;

        double distSq = entity.squaredDistanceTo(mc.player);
        return distSq > 2500; // Beyond 50 blocks
    }
}
