package com.potatooptimizerai.performance;

/**
 * Enumeration of optimization modes for dynamic FPS adjustment
 */
public enum PerformanceMode {
    NORMAL("NORMAL", 1.0f, 100, 4900),          // 100 blocks, 70^2
    BALANCED("BALANCED", 0.85f, 85, 2500),     // 50 blocks, 50^2
    AGGRESSIVE("AGGRESSIVE", 0.7f, 60, 1600);  // 40 blocks, 40^2

    public final String name;
    public final float optimizationLevel;   // 0.0f to 1.0f
    public final int targetFps;
    public final int cullingDistanceSq;

    PerformanceMode(String name, float optimizationLevel, int targetFps, int cullingDistanceSq) {
        this.name = name;
        this.optimizationLevel = optimizationLevel;
        this.targetFps = targetFps;
        this.cullingDistanceSq = cullingDistanceSq;
    }

    public static PerformanceMode fromString(String str) {
        try {
            return PerformanceMode.valueOf(str.toUpperCase());
        } catch (IllegalArgumentException e) {
            return BALANCED;
        }
    }
}
