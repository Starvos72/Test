package com.potatooptimizerai.performance;

import net.minecraft.client.MinecraftClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Core AI Performance Handler - Monitors FPS and dynamically adjusts optimization
 */
public class PerformanceHandler {
    private static final Logger LOGGER = LogManager.getLogger("PotatoOptimizerAI");
    private static final int FPS_SAMPLE_WINDOW = 300; // Sample over 5 seconds (300 ticks at 60fps)
    private static final int FPS_CHECK_INTERVAL = 20; // Check FPS every 20 ticks (1/3 second)

    private static PerformanceMode currentMode = PerformanceMode.BALANCED;
    private static PerformanceMode targetMode = PerformanceMode.BALANCED;
    
    private static long[] frameTimeSamples = new long[FPS_SAMPLE_WINDOW];
    private static int frameTimeIndex = 0;
    private static long lastFrameTime = 0;
    private static int tickCounter = 0;
    private static double currentFps = 60.0;
    private static boolean aiOptimizationEnabled = true;
    
    // Mode transition smoothing
    private static int modeStabilityCounter = 0;
    private static final int MODE_STABILITY_THRESHOLD = 3; // Require 3 checks before switching

    /**
     * Called every game tick to monitor FPS and adjust optimization
     */
    public static void tick() {
        if (!aiOptimizationEnabled) return;

        tickCounter++;
        MinecraftClient mc = MinecraftClient.getInstance();
        
        if (mc == null || mc.isRunning() == false) return;

        // Sample frame time
        long currentTime = System.nanoTime();
        if (lastFrameTime > 0) {
            long frameTime = currentTime - lastFrameTime;
            frameTimeSamples[frameTimeIndex] = frameTime;
            frameTimeIndex = (frameTimeIndex + 1) % FPS_SAMPLE_WINDOW;
        }
        lastFrameTime = currentTime;

        // Check FPS periodically
        if (tickCounter % FPS_CHECK_INTERVAL == 0) {
            updateCurrentFps();
            evaluatePerformanceMode();
        }
    }

    private static void updateCurrentFps() {
        // Calculate average frame time from samples
        long totalFrameTime = 0;
        int validSamples = 0;
        
        for (long time : frameTimeSamples) {
            if (time > 0) {
                totalFrameTime += time;
                validSamples++;
            }
        }

        if (validSamples > 0) {
            long avgFrameTime = totalFrameTime / validSamples;
            currentFps = (avgFrameTime > 0) ? 1_000_000_000.0 / avgFrameTime : 60.0;
            currentFps = Math.min(currentFps, 240.0); // Cap at 240 FPS
        }
    }

    /**
     * Evaluates current FPS and determines if mode should change
     */
    private static void evaluatePerformanceMode() {
        PerformanceMode recommendedMode = determineOptimalMode(currentFps);

        if (recommendedMode != targetMode) {
            targetMode = recommendedMode;
            modeStabilityCounter = 1;
        } else {
            modeStabilityCounter++;
        }

        // Only switch modes after stability threshold is met
        if (modeStabilityCounter >= MODE_STABILITY_THRESHOLD && recommendedMode != currentMode) {
            switchMode(recommendedMode);
        }
    }

    /**
     * Determines optimal mode based on current FPS
     */
    private static PerformanceMode determineOptimalMode(double fps) {
        // Target FPS ranges for each mode
        if (fps >= 100) {
            return PerformanceMode.NORMAL;
        } else if (fps >= 75) {
            return PerformanceMode.BALANCED;
        } else {
            return PerformanceMode.AGGRESSIVE;
        }
    }

    /**
     * Switches optimization mode with logging
     */
    private static void switchMode(PerformanceMode newMode) {
        if (newMode == currentMode) return;
        
        currentMode = newMode;
        LOGGER.info("✓ Performance Mode switched to: {} (FPS: {:.1f})", newMode.name, currentFps);
    }

    // ========== Getters ==========
    public static PerformanceMode getCurrentMode() {
        return currentMode;
    }

    public static void setCurrentMode(PerformanceMode mode) {
        currentMode = mode;
        targetMode = mode;
        LOGGER.info("✓ Performance Mode manually set to: {}", mode.name);
    }

    public static double getCurrentFps() {
        return currentFps;
    }

    public static boolean isAIOptimizationEnabled() {
        return aiOptimizationEnabled;
    }

    public static void setAIOptimizationEnabled(boolean enabled) {
        aiOptimizationEnabled = enabled;
        LOGGER.info("✓ AI Optimization: {}", enabled ? "ENABLED" : "DISABLED");
    }

    public static float getOptimizationLevel() {
        return currentMode.optimizationLevel;
    }

    public static int getCullingDistance() {
        return currentMode.cullingDistanceSq;
    }
}
