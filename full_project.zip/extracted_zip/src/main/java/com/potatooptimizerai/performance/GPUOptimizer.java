package com.potatooptimizerai.performance;

/**
 * GPU Optimization - Reduces draw calls and rendering overhead
 */
public class GPUOptimizer {
    
    public static boolean skipHiddenObjects = true;
    public static boolean lowerChunkMeshFrequency = true;
    public static boolean reduceAnimatedTextures = false;
    public static boolean enableUltraLowGPUMode = false;
    public static boolean disableFireAnimations = false;
    public static boolean disableExplosionAnimations = false;
    public static boolean reduceWaterLavaAnimations = false;

    /**
     * Determines draw call reduction multiplier
     */
    public static float getDrawCallMultiplier(float optimizationLevel) {
        if (optimizationLevel < 0.5f) return 0.6f;  // 60% of draw calls
        if (optimizationLevel < 0.75f) return 0.8f; // 80% of draw calls
        return 1.0f;
    }

    /**
     * Gets chunk mesh rebuild frequency
     */
    public static int getChunkMeshRebuildFrequency(float optimizationLevel) {
        if (optimizationLevel < 0.5f) return 4;  // Every 4 ticks
        if (optimizationLevel < 0.75f) return 2; // Every 2 ticks
        return 1;                               // Every tick
    }

    /**
     * Checks if animated textures should be reduced
     */
    public static boolean shouldReduceAnimatedTextures() {
        return reduceAnimatedTextures;
    }

    /**
     * Checks if ultra-low GPU mode should be applied
     */
    public static boolean isUltraLowGPUModeEnabled() {
        return enableUltraLowGPUMode;
    }

    /**
     * Gets texture animation speed multiplier
     */
    public static float getTextureAnimationSpeed(float optimizationLevel) {
        if (optimizationLevel < 0.5f) return 0.5f;  // 50% speed
        if (optimizationLevel < 0.75f) return 0.75f; // 75% speed
        return 1.0f;
    }

    /**
     * Checks if special effects should be disabled
     */
    public static boolean shouldDisableSpecialEffects(float optimizationLevel) {
        return optimizationLevel < 0.6f;
    }
}
