package com.potatooptimizerai.performance;

/**
 * Chunk & World Optimization - Optimizes chunk loading and rendering
 */
public class ChunkOptimizer {
    
    public static boolean throttleChunkMeshRebuild = true;
    public static boolean limitChunkLoadingSpeed = true;
    public static boolean skipOffscreenChunks = true;
    public static boolean reduceBlockEntityInFarChunks = true;
    
    public static int chunkMeshRebuildThrottle = 2; // Rebuild every 2nd tick
    public static int maxChunksLoadedPerTick = 4;
    public static int maxBlockEntityTickDistance = 70; // blocks

    private static int meshRebuildCounter = 0;

    /**
     * Determines if chunk mesh should be rebuilt this tick
     */
    public static boolean shouldRebuildChunkMesh() {
        if (!throttleChunkMeshRebuild) return true;

        meshRebuildCounter++;
        if (meshRebuildCounter >= chunkMeshRebuildThrottle) {
            meshRebuildCounter = 0;
            return true;
        }
        return false;
    }

    /**
     * Gets maximum chunks that can be loaded this tick
     */
    public static int getMaxChunksToLoad() {
        if (!limitChunkLoadingSpeed) return 10;
        return maxChunksLoadedPerTick;
    }

    /**
     * Checks if a chunk is far enough to skip rendering
     */
    public static boolean shouldSkipChunkRendering(int chunkX, int chunkZ, int playerChunkX, int playerChunkZ) {
        if (!skipOffscreenChunks) return false;

        int distChunks = Math.max(
            Math.abs(chunkX - playerChunkX),
            Math.abs(chunkZ - playerChunkZ)
        );

        // Skip chunks beyond 20 chunks (320 blocks)
        return distChunks > 20;
    }

    /**
     * Checks if block entities in this chunk should be ticked
     */
    public static boolean shouldTickBlockEntitiesInChunk(int chunkX, int chunkZ, int playerChunkX, int playerChunkZ) {
        if (!reduceBlockEntityInFarChunks) return true;

        int distChunks = Math.max(
            Math.abs(chunkX - playerChunkX),
            Math.abs(chunkZ - playerChunkZ)
        );

        // Skip block entity ticking in chunks beyond 5 chunks (80 blocks)
        return distChunks <= 5;
    }
}
