package com.potatooptimizerai.performance;

import net.minecraft.particle.ParticleEffect;

/**
 * Particle & Visual Effects Optimizer
 */
public class ParticleOptimizer {
    
    // Particle effect controls
    public static boolean reduceExplosionParticles = true;
    public static boolean reduceSmokeParticles = true;
    public static boolean reduceSplashParticles = true;
    public static boolean disableWeatherVisuals = false;
    public static boolean disableSkyEffects = false;
    public static boolean disableFog = false;
    public static boolean disableVignette = false;
    public static boolean disableHurtCameraShake = false;
    public static boolean disableBeaconBeams = false;
    public static boolean disableEndCrystalEffects = false;
    public static boolean reduceEntityShadows = false;
    
    // Animation controls
    public static boolean disableFireAnimations = false;
    public static boolean disableExplosionAnimations = false;
    public static boolean reduceWaterLavaAnimations = false;
    public static boolean disableAnimatedTextures = false;

    /**
     * Determines if a particle effect should be rendered
     */
    public static boolean shouldRenderParticle(ParticleEffect particle, float optimizationLevel) {
        if (particle == null) return true;

        String particleType = particle.getType().toString();

        // Check aggressive reduction first
        if (optimizationLevel < 0.7f) {
            if (particleType.contains("explosion") && reduceExplosionParticles) return false;
            if (particleType.contains("smoke") && reduceSmokeParticles) return false;
            if (particleType.contains("splash") && reduceSplashParticles) return false;
        }

        // Standard reductions
        if (reduceExplosionParticles && particleType.contains("explosion")) return false;
        if (reduceSmokeParticles && particleType.contains("smoke")) return false;
        if (reduceSplashParticles && particleType.contains("splash")) return false;

        return true;
    }

    /**
     * Gets particle reduction multiplier based on optimization level
     */
    public static float getParticleMultiplier(float optimizationLevel) {
        if (optimizationLevel < 0.5f) return 0.2f;  // 20% particles
        if (optimizationLevel < 0.75f) return 0.5f; // 50% particles
        return 1.0f;
    }

    /**
     * Check if weather visuals should be disabled
     */
    public static boolean shouldDisableWeather() {
        return disableWeatherVisuals;
    }

    /**
     * Check if sky effects should be disabled
     */
    public static boolean shouldDisableSkyEffects() {
        return disableSkyEffects;
    }

    /**
     * Check if fog should be disabled
     */
    public static boolean shouldDisableFog() {
        return disableFog;
    }

    /**
     * Check if vignette should be disabled
     */
    public static boolean shouldDisableVignette() {
        return disableVignette;
    }

    /**
     * Check if hurt camera shake should be disabled
     */
    public static boolean shouldDisableHurtShake() {
        return disableHurtCameraShake;
    }

    /**
     * Check if entity shadows should be reduced
     */
    public static boolean shouldReduceShadows(float optimizationLevel) {
        return reduceEntityShadows || optimizationLevel < 0.6f;
    }
}
