package com.potatooptimizerai.performance;

import net.minecraft.client.MinecraftClient;

/**
 * Background Task Limiter - Reduces non-essential background processes
 */
public class BackgroundTaskLimiter {
    
    public static boolean limitAmbientSounds = true;
    public static boolean pauseWeatherCycles = false;
    public static boolean pauseBackgroundLogic = true;
    public static boolean reduceBackgroundUpdates = true;
    public static boolean pauseIdleMode = false;
    
    private static long lastPlayerInput = 0;
    private static final long IDLE_TIMEOUT = 30_000; // 30 seconds

    /**
     * Updates last player input time
     */
    public static void updatePlayerInput() {
        lastPlayerInput = System.currentTimeMillis();
    }

    /**
     * Checks if player has been idle
     */
    public static boolean isPlayerIdle() {
        if (!pauseIdleMode) return false;
        return System.currentTimeMillis() - lastPlayerInput > IDLE_TIMEOUT;
    }

    /**
     * Determines if ambient sounds should be limited
     */
    public static boolean shouldLimitAmbientSounds() {
        return limitAmbientSounds;
    }

    /**
     * Determines if weather cycle should be paused
     */
    public static boolean shouldPauseWeatherCycle() {
        return pauseWeatherCycles && isPlayerIdle();
    }

    /**
     * Determines if background tasks should be reduced
     */
    public static boolean shouldReduceBackgroundTasks() {
        return reduceBackgroundUpdates;
    }

    /**
     * Gets background task update frequency multiplier
     */
    public static float getBackgroundTaskMultiplier(MinecraftClient mc) {
        if (!reduceBackgroundUpdates) return 1.0f;

        // Reduce background tasks when far render distance
        if (mc != null && mc.options != null) {
            int renderDistance = mc.options.getViewDistance().getValue();
            if (renderDistance > 16) return 0.7f;  // 70% when high render distance
            if (renderDistance > 12) return 0.85f; // 85%
        }

        return 1.0f;
    }

    /**
     * Gets ambient sound volume multiplier
     */
    public static float getAmbientSoundMultiplier() {
        if (!limitAmbientSounds) return 1.0f;
        return 0.75f; // 75% volume
    }
}
