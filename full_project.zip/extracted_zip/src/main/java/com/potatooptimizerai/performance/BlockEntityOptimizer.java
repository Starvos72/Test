package com.potatooptimizerai.performance;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.MinecraftClient;

/**
 * Block Entity Optimization - Reduces ticking of distant block entities
 */
public class BlockEntityOptimizer {
    
    public static int blockEntityThrottleDistance = 50; // blocks
    public static boolean enableBlockEntityOptimization = true;
    public static boolean optimizeFarms = true;
    public static boolean optimizeRedstone = true;

    /**
     * Determines if a block entity should be ticked
     */
    public static boolean shouldTickBlockEntity(BlockEntity blockEntity, MinecraftClient mc) {
        if (!enableBlockEntityOptimization || mc.player == null) return true;

        double distSq = blockEntity.getPos().getSquaredDistance(mc.player.getEyePos());
        int thresholdSq = blockEntityThrottleDistance * blockEntityThrottleDistance;

        if (distSq > thresholdSq) {
            // Don't tick far block entities
            return false;
        }

        return true;
    }

    /**
     * Gets tick frequency reduction for block entities at distance
     */
    public static int getTickFrequencyReduction(BlockEntity blockEntity, MinecraftClient mc) {
        if (!enableBlockEntityOptimization || mc.player == null) return 1;

        double distSq = blockEntity.getPos().getSquaredDistance(mc.player.getEyePos());

        // Reduce update frequency based on distance
        if (distSq > 4900) return 20;  // Every 20 ticks (1 second)
        if (distSq > 2500) return 10;  // Every 10 ticks
        if (distSq > 1600) return 5;   // Every 5 ticks
        return 1;                      // Every tick
    }

    /**
     * Checks if hoppers should have reduced updates
     */
    public static boolean shouldOptimizeHopper(BlockEntity blockEntity, MinecraftClient mc) {
        if (!(blockEntity instanceof HopperBlockEntity)) return false;
        
        return optimizeFarms && shouldThrottleEntity(blockEntity, mc, 40);
    }

    /**
     * Checks if furnaces should have reduced updates
     */
    public static boolean shouldOptimizeFurnace(BlockEntity blockEntity, MinecraftClient mc) {
        if (!(blockEntity instanceof FurnaceBlockEntity)) return false;

        // Less aggressive with furnaces to avoid visual issues
        return shouldThrottleEntity(blockEntity, mc, 60);
    }

    /**
     * Checks if redstone components should have reduced updates
     */
    public static boolean shouldThrottleRedstone(BlockEntity blockEntity, MinecraftClient mc) {
        if (!optimizeRedstone) return false;
        
        return shouldThrottleEntity(blockEntity, mc, 50);
    }

    /**
     * Generic throttle check
     */
    private static boolean shouldThrottleEntity(BlockEntity entity, MinecraftClient mc, int distance) {
        if (mc.player == null) return false;
        return entity.getPos().getSquaredDistance(mc.player.getEyePos()) > (distance * distance);
    }
}
