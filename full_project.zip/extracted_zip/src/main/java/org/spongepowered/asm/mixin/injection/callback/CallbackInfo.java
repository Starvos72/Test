package org.spongepowered.asm.mixin.injection.callback;

public class CallbackInfo {
    public void cancel() {
    }
}
