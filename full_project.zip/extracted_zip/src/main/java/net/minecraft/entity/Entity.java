package net.minecraft.entity;

public class Entity {
    public double squaredDistanceTo(Object player) {
        return 0.0;
    }
}
