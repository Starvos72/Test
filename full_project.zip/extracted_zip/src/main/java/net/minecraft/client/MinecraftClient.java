package net.minecraft.client;

public class MinecraftClient {
    public Object player;
    
    public static MinecraftClient getInstance() {
        return null;
    }
}
