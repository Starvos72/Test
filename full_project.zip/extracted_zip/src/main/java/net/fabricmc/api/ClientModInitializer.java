package net.fabricmc.api;

public interface ClientModInitializer {
    void onInitializeClient();
}
